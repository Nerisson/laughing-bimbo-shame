Projet OpenGL : Blandine Decherf - Simon Fabry - St�phane Guinard

*****************************************************************

Le programme compil� se situe dans le dossier obj.

Le dossier src contient les fichiers source et le main.cpp.

Pour lancer le programme, il faut ouvrir codeblocks et charger le fichier Project-V0.cbp.

Dans le monde, on peut se d�placer avec les deux premi�res cam�ras en utilisant les touches "fl�che haut" et "fl�che bas", la troisi�me cam�ra montre une vue de dessus, et en passans � la quatri�me cam�ra, on a acc�s aux cam�ras des trains.
On change de cam�ra en appuyant sur "c" et lorsqu'on est sur un train, on passe � un autre train en appuyant sur "n".
La touches "�chap" permet de quitter le monde.