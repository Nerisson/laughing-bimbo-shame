#define TAILLE_MAX 1024 // Tableau de taille 1024
#define RNOVA 3.E18 //
#define NOVAL -212121212 //
#define MAX(x,y) ((x)>(y)?(x):(y))
#define MIN(x,y) ((x)<(y)?(x):(y))

